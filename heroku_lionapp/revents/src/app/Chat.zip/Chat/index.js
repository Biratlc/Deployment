import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { Route, BrowserRouter as Router } from 'react-router-dom';
import * as serviceWorker from './serviceWorker';
import LoginComponent from './Login/login';
import SignupComponent from './Signup/signup';
import DashboardComponent from './Dashboard/dashboard';

const firebase = require("firebase");
require("firebase/firestore"); // Required for side-effects?????

firebase.initializeApp({
  apiKey: "AIzaSyB708TP9xozXPg4Rp20GYRft5XauObzir8",
  authDomain: "chatapp-af00d.firebaseapp.com",
  databaseURL: "https://chatapp-af00d.firebaseio.com",
  projectId: "chatapp-af00d",
  storageBucket: "chatapp-af00d.appspot.com",
  messagingSenderId: "467759620915",
  appId: "1:467759620915:web:9d98af9efb8bbe009f1446",
  measurementId: "G-S4CP6KKT41"
});

const routing = (
  <Router>
    <div id='routing-container'>
      <Route path='/login' component={LoginComponent}></Route>
      <Route path='/signup' component={SignupComponent}></Route>
      <Route path='/dashboard' component={DashboardComponent}></Route>
    </div>
  </Router>
);

ReactDOM.render(routing, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
